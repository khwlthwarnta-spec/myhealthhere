===== تعليمات فتح المشروع في Android Studio =====

الخطوة 1: ثبّت الحزم المطلوبة
--------------------------------
افتح PowerShell او CMD في هذا المجلد وشغّل:
    npm install

انتظر حتى ينتهي (دقيقتان تقريبا).

الخطوة 2: افتح Android Studio
--------------------------------
- اضغط Open
- اختر مجلد "android" الموجود داخل هذا المجلد
- انتظر Gradle Sync (دقيقة او دقيقتين)

الخطوة 3: ابنِ APK
--------------------------------
- من القائمة: Build > Build Bundle(s)/APK(s) > Build APK(s)
- ستجد الملف في: android\app\build\outputs\apk\debug\app-debug.apk
