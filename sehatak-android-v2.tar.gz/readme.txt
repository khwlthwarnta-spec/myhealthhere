===== تعليمات بناء APK =====

الخطوة 1 - في PowerShell داخل هذا المجلد:
    npm install

الخطوة 2 - في Android Studio:
    - Open -> اختر مجلد "android"
    - عند السؤال اختر: Android Studio SDK
    - انتظر Gradle Sync
    - Build > Build Bundle(s)/APK(s) > Build APK(s)

APK يكون في:
android\app\build\outputs\apk\debug\app-debug.apk
